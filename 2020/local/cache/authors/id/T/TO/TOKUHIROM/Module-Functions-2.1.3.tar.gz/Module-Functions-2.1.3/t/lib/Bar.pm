package Bar;
use strict;
use warnings;
use utf8;
use parent qw/Exporter/;

use File::Spec::Functions qw/catfile/;

sub bar { '5963' }

sub _barbar { '0843' }

1;

