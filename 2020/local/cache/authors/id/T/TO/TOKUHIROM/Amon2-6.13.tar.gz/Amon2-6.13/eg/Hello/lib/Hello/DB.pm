package Hello::DB;
use DBIx::Skinny;
1;
