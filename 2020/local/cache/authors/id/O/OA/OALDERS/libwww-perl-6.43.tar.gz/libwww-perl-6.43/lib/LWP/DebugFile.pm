package LWP::DebugFile;

our $VERSION = '6.43';

# legacy stub

1;
