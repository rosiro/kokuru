# this package is identical, but will be ->isa('Time::Piece::Twin');
package Time::Piece::Twin;
use base qw(Time::Piece);
our $VERSION = "0.01";
