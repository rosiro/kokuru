Devel-PPPort
============

[![](https://github.com/Dual-Life/Devel-PPPort/workflows/linux/badge.svg)](https://github.com/Dual-Life/Devel-PPPort/actions) [![](https://github.com/Dual-Life/Devel-PPPort/workflows/macos/badge.svg)](https://github.com/Dual-Life/Devel-PPPort/actions) [![](https://github.com/Dual-Life/Devel-PPPort/workflows/windows/badge.svg)](https://github.com/Dual-Life/Devel-PPPort/actions)

Perl/Pollution/Portability
